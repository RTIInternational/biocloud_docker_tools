Patching the source code:
$ tar zxvf generic-metal-2010-02-08.tar.gz
$ cd generic-metal
$ patch -b -p1 < ../metal-2010-02-08-modified2.patch
